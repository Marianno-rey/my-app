const Homepage = () => {
  return (
    <div>homepage</div>
  )
};

export default Homepage;