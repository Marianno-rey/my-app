import { Container } from 'react-bootstrap'

const Profile = () => {

  return (
    <Container>
      
    </Container>
  )
}

export default Profile